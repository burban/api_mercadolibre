<?php 


    function code()
    {
        
        $_GLOBALS['codex'] = 'codigoml';

        $curl = curl_init();
        
        $fields = array(
            'grant_type' => 'authorization_code',
            'client_id' => '3677532988023597',
            'client_secret' => '1YaLi2lNUXgxUDqS3Wxd7zSl3mvFTNY1',
            'code' => 'TG-61d898a26e9a52001c6321c6-64580578',
            'redirect_uri' => 'https://quindosmontalva.cl/request-mercadolibre'
        );
    
        error_log("codex::".$_GLOBALS['codex']);
        
        error_log('API Test ..x.d.d.d');
        
        error_log(' array ::' . print_r($fields,true));    
    }

    


?>